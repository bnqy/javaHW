class ClassTwo extends ClassOne{

	//void Printing(){
	//	System.out.println("Retire age is "+retirementAge); 	OVERRIDED FINAL METHOD ERROR EMERGES
	//}

}